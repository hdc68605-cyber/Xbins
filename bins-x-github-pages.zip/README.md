# BINS X - GitHub Pages

## Archivos
- `index.html` -> página principal
- `.nojekyll` -> ayuda a que GitHub Pages sirva el sitio sin procesarlo con Jekyll

## Cómo publicarlo
1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html` y `.nojekyll`.
3. Entra a **Settings** del repositorio.
4. Abre **Pages**.
5. En **Build and deployment**, elige:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
6. Guarda.
7. Espera un momento y GitHub Pages te dará un enlace público.

## Enlace del botón
El botón abre este grupo:
https://chat.whatsapp.com/K9ImxbaMd7MJdJPbpC9GEL
